INSERT INTO juguete (codigo_barras,nombre_juguete,precio,clasificacion) VALUES (1000,'Juguete Prueba',-10,1);
